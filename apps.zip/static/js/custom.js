$(document).ready(function () {
    $(document).on('click', '.btnShowMenuMain', function (e) {
        $(this).parents('.header_top_container').next().slideToggle(0)
    });
})