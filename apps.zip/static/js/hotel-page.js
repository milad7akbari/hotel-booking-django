$(document).ready(function () {

    function modalImages(ref, get) {
        $.ajax({
            type:"GET",
            data: {'get' : get },
            url: "/hotel-l/images/"+ref,
            success: function(data){
                $('#_partial').empty().html(data);
            }
        });
    }

    $(document).on('click' , '.btnShowImages' , function () {
        const id = $(this).attr('data-ref');
        const get = $(this).attr('data-get');
        modalImages(id, get)
    })
    $(document).on('click' , '.btnHideImages' , function () {
        $('#_partial').empty();
    })
})